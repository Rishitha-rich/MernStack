//import React from 'react'
import React, { useEffect, useState } from 'react'
import ProductCard from '../components/ProductCard'

const Product = () => {
  const img = "https://loremflickr.com/640/480/cats"
  const name = "Bespoke Fresh Mouse"
 const price = "101.00"
 
  return (
    <>
  
    <div className='w-screen h-full flex flex-col justify-center items-center'>
                <div className='w-full h-[4rem] flex justify-center items-center'>
              
                </div>
                <div className='w-screen h-full flex justify-start items-start flex-row flex-wrap mt-14 mb-12 gap-y-20 gap-x-2'>
</div>
</div>
    </>
  )
}

export default Product