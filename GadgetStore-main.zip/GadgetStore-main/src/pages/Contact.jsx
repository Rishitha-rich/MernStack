//import React from 'react'

const Contact = () => {
  return (
    <div>This is Contact Page</div>
  )
}

export default Contact